<?php

namespace App\Http\Livewire\Campo;

use Livewire\Component;

class SelectCampoAgricola extends Component
{
    public function render()
    {
        return view('livewire.campo.select-campo-agricola');
    }
}
