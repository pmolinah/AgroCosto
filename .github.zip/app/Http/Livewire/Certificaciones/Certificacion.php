<?php

namespace App\Http\Livewire\Certificaciones;

use Livewire\Component;

class Certificacion extends Component
{
    public function render()
    {
     
    }
}
