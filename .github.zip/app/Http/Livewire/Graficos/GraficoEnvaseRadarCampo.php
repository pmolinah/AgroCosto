<?php

namespace App\Http\Livewire\Graficos;

use Livewire\Component;

class GraficoEnvaseRadarCampo extends Component
{
    public function render()
    {
        return view('livewire.graficos.grafico-envase-radar-campo');
    }
}
