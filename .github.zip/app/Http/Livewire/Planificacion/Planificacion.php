<?php

namespace App\Http\Livewire\Planificacion;

use Livewire\Component;

class Planificacion extends Component
{
    public function render()
    {
        return view('livewire.planificacion.planificacion');
    }
}
