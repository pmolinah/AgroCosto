<?php

namespace App\Charts;

use ConsoleTVs\Charts\Classes\Chartsjs\Chart;

class GraficoPrueba extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
