<x-dashBoard>
    @livewire('bodega.bodega-edit', ['factura_id' => $factura_id])
</x-dashBoard>