<x-dashBoard>
    <div class="text-center py-6">
        @livewire('certificaciones.crud-certificacion')
    </div>
</x-dashBoard>