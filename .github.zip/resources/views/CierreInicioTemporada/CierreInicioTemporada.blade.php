<x-dashBoard>
    <div class="py-2">
        @livewire('cierre-inicio-temporada.cierre-inicio-temporada')
    </div>
</x-dashBoard>