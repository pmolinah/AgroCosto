<x-dashBoard>
    <div class="py-2">
        @livewire('actividades.registro-actividades')
    </div>
</x-dashBoard>