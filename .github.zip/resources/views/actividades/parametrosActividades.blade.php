<x-dashBoard>
    <div class="py-2">
        @livewire('actividades.parametros-actividades')
    </div>
</x-dashBoard>