<?php

namespace App\Http\Livewire\Parametros;

use Livewire\Component;

class EditVariedad extends Component
{
    public function render()
    {
        return view('livewire.parametros.edit-variedad');
    }
}
