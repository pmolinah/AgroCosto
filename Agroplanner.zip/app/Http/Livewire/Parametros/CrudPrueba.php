<?php

namespace App\Http\Livewire\Parametros;

use Livewire\Component;

class CrudPrueba extends Component
{
    public function render()
    {
        return view('livewire.parametros.crud-prueba');
    }
}
