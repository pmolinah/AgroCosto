<a href="/">
<div class="text-center">
                        <img
                            src="{{ asset('storage/logo.png') }}"
                            class="mx-auto mb-4 w-32 rounded-lg"
                            alt="Avatar" />
                        <h5 class="mb-2 text-xl font-medium leading-tight">Plataforma Administradora de Campos</h5>
                        <p class="text-neutral-500 dark:text-neutral-400">Organice a su manera el control de sus campos</p>
                    </div>
</a>
