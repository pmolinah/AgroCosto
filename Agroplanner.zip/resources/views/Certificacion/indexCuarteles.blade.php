<x-dashBoard>
    <div class="py-3">
        @livewire('certificaciones.crud-certificacion-cuartel')
    </div>
</x-dashBoard>
