<x-dashBoard>
    @livewire('bodega.bodega-ingreso')
</x-dashBoard>
