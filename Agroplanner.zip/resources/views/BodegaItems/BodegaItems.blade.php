<x-dashBoard>
    @livewire('parametros.crud-bodega')
</x-dashBoard>
