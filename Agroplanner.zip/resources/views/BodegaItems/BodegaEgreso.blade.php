<x-dashBoard>
    @livewire('bodega.bodega-egreso')
</x-dashBoard>
