<x-dashBoard>

    <div class="mx-auto sm:px-6 lg:px-8">

        <div class=" overflow-hidden">
            <!-- contenido -->
            @livewire('campo.create-campo-cuartel')
            {{-- contenido --}}
        </div>

    </div>

</x-dashBoard>
